public class Contact {
    //Global Variables - describe the object
    private int contactID;
    private String contactName;
    private String contactNumber;

    public Contact(){
        //null constructor - has no values
    }
    
    public Contact(int id, String name, String number) {
     //Constructor with fields - has values
     
     contactID = id;
     contactName = name;
     contactNumber = number;
    }
    //Methods - What can the object do.
    
    public void viewContact() {
        System.out.println("------------------------------");
        System.out.println("Contact ID: " + contactName);
        System.out.println("Contact Names: " + contactName);
        System.out.println("Contact Number: " + contactNumber);
        System.out.println("-----------------------------------");
    }

    public void setContactID(int id) {
        contactID = id;
    }
    public int getContactID() {
		return contactID;
	}
	
	public void setContactName(String name) {
		contactName = name;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactNumber(String number) {
		contactNumber = number;
	}
    
	public String getContactNumber() {
		return contactNumber;
	}
}