import java.util.ArrayList;
import java.util.Scanner;

public class ContactApp {
	
	static ArrayList<Contact> addressBook = new ArrayList<Contact>();
	static int centra1ID = 12;
	static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
		prePopulate();
		menu();
    }
	public static void menu() {
		System.out.println("Press 1 to Create New Contact");
		System.out.println("Press 2 to View All Contacts");
		
		String choice = input.next();
		switch(choice) {
			case "1":{
				createContact();
				break;
			}
			case "2": {
				viewContact();
				break;
			}
		}
		menu();
	}
    private static void viewContact() {
		// TODO Auto-generated method stub
		for(Contact c: addressBook) {
			
			System.out.println("--------------------------------");
			System.out.print(c.getContactID() + "/t");
			System.out.print(c.getContactName() + "/t");
			System.out.println(c.getContactNumber());
			System.out.println("---------------------------------");
		}
	}
	private static void createContact() {
		// TODO Auto-generated method stub
		
	}
	public static void prePopulate() {
		Contact c1 = new Contact();
		//Constructor with fields, we set values in one line
		Contact c2 = new Contact(10, "Ann", "087-6100011");
		Contact c3 = new Contact(11, "Donald", "087-1234566");
		//Null constructor, we need set Methods to set each value
		c1.setContactID(9);
		c1.setContactName("Mary");
		c1.setContactNumber("087-62019273");
		addressBook.add(c1);
		addressBook.add(c2);
		addressBook.add(c3);
		
//		System.out.println(c1.getContactID() + "\t" + c1.getContactName() + "\t" + c1.getContactNumber());
//		System.out.println(c2.getContactID() + "\t" + c2.getContactName() + "\t" + c2.getContactNumber());
//		System.out.println(c3.getContactID() + "\t" + c3.getContactName() + "\t" + c3.getContactNumber());
		
	}

}